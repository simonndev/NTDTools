﻿using System.Windows.Controls;

namespace NtdTools.Modules.TrainingSolutions.Views
{
    /// <summary>
    /// Interaction logic for WholesalersNavItemView.xaml
    /// </summary>
    public partial class WholesalersNavItemView : ListBoxItem
    {
        public WholesalersNavItemView()
        {
            InitializeComponent();
        }
    }
}
