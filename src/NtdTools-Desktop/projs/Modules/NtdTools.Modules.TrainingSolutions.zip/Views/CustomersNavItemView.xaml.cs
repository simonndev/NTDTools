﻿using System.Windows.Controls;

namespace NtdTools.Modules.TrainingSolutions.Views
{
    /// <summary>
    /// Interaction logic for CustomersNavItemView.xaml
    /// </summary>
    public partial class CustomersNavItemView : ListBoxItem
    {
        public CustomersNavItemView()
        {
            InitializeComponent();
        }
    }
}
