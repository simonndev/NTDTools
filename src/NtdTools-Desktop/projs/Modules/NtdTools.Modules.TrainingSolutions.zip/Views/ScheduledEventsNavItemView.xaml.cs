﻿using System.Windows.Controls;

namespace NtdTools.Modules.TrainingSolutions.Views
{
    /// <summary>
    /// Interaction logic for ScheduledEventsNavItemView.xaml
    /// </summary>
    public partial class ScheduledEventsNavItemView : ListBoxItem   
    {
        public ScheduledEventsNavItemView()
        {
            InitializeComponent();
        }
    }
}
