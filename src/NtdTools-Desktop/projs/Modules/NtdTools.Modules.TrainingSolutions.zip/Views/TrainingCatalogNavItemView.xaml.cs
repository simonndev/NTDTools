﻿using System.Windows.Controls;

namespace NtdTools.Modules.TrainingSolutions.Views
{
    /// <summary>
    /// Interaction logic for TrainingCatalogNavItemView.xaml
    /// </summary>
    public partial class TrainingCatalogNavItemView : ListBoxItem
    {
        public TrainingCatalogNavItemView()
        {
            InitializeComponent();
        }
    }
}
